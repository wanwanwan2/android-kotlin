package com.cookandroid.flash

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.cookandroid.flash.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private val binding by lazy {
        ActivityMainBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        val torch = Torch(this)

        binding.flashSwitch.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                torch.flashOn()
            } else {
                torch.flashOff()
            }
        }
    }
}